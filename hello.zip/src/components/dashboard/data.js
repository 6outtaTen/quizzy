import picture from '../../images/profile-picture.png'

export default [
    {
        title: "Capitals of the world",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut ",
        photo: picture
    },
    {
        title: "Capitals of the world",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut ",
        photo: picture
    },
    {
        title: "Capitals of the world",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut ",
        photo: picture
    },
    {
        title: "Capitals of the world",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut ",
        photo: picture
    }
]