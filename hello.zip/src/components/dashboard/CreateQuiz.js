import React from 'react'

export default function CreateQuiz() {
    return (
        <div className="create-quiz">
            <div className="create-quiz-title">Create a quiz</div>
            <button className="create-quiz-button">+</button>
        </div>
    )
}
